(function (root) {
  'use strict';
  const game = root.IslandMystery;
  const { $ } = game.ui;
  let state = null;
  function refreshWelcome() { game.ui.welcome(game.storage.load(), Boolean(state)); }
  function persist() { game.ui.saveStatus(game.storage.save(state)); }
  function openGame() { game.ui.render(state); game.ui.screen('game'); }
  function newGame() { state = game.state.create(); persist(); openGame(); }
  function requestNew() {
    const saved = game.storage.load();
    if (state || saved.status === 'loaded' || saved.status === 'invalid') $('restart-dialog').showModal();
    else newGame();
  }
  function menu() { refreshWelcome(); game.ui.screen('welcome'); }
  $('new-button').addEventListener('click', requestNew);
  $('restart-button').addEventListener('click', requestNew);
  $('confirm-restart').addEventListener('click', () => { $('restart-dialog').close(); newGame(); });
  $('cancel-restart').addEventListener('click', () => $('restart-dialog').close());
  $('continue-button').addEventListener('click', () => {
    const result = game.storage.load();
    state = state || result.state;
    if (state) { openGame(); game.ui.saveStatus(result.status === 'loaded' && JSON.stringify(result.state) === JSON.stringify(state)); }
    else refreshWelcome();
  });
  $('map-locations').addEventListener('click', event => {
    const button = event.target.closest('[data-location]');
    if (!button || !state) return;
    state = game.state.transition(state, { type: 'SELECT_LOCATION', location: button.dataset.location });
    game.ui.render(state); persist();
  });
  $('plan-button').addEventListener('click', () => {
    if (!state) return;
    state = game.state.transition(state, { type: 'PLAN_EXPEDITION' });
    game.ui.render(state); persist();
  });
  $('menu-button').addEventListener('click', menu);
  $('home-link').addEventListener('click', event => { event.preventDefault(); menu(); });
  $('help-button').addEventListener('click', () => $('help-dialog').showModal());
  $('close-help').addEventListener('click', () => $('help-dialog').close());
  refreshWelcome();
})(globalThis);
