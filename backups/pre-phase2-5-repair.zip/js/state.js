(function (root) {
  'use strict';
  const game = root.IslandMystery;
  const locationIds = game.data.locations.map(item => item.id);
  function create(now = new Date().toISOString()) {
    return { version: game.data.version, day: 1, phase: 'preparation', selectedLocation: 'coast', plannedLocation: null,
      resources: { food: 12, water: 12, medicine: 3, parts: 2 },
      players: game.data.survivors.map(person => ({ ...person, role: null, status: 'healthy' })),
      log: [{ text: '여섯 명이 해안에서 깨어났다. 공동 물자를 모으고 섬의 지형을 기록했다.', time: now }], updatedAt: now };
  }
  function valid(state) {
    if (!state || state.version !== 1 || state.day !== 1 || state.phase !== 'preparation' || !locationIds.includes(state.selectedLocation)) return false;
    if (state.plannedLocation !== null && !locationIds.includes(state.plannedLocation)) return false;
    if (!state.resources || !game.data.resources.every(item => Number.isSafeInteger(state.resources[item.id]) && state.resources[item.id] >= 0)) return false;
    if (!Array.isArray(state.players) || state.players.length !== 6 || !game.data.survivors.every((person, i) => {
      const candidate = state.players[i];
      return candidate && candidate.id === person.id && candidate.name === person.name && candidate.personality === person.personality && candidate.initials === person.initials && candidate.role === null && candidate.status === 'healthy';
    })) return false;
    return Array.isArray(state.log) && state.log.length > 0 && state.log.length <= 50 && state.log.every(entry => entry && typeof entry.text === 'string' && entry.text.length <= 500 && typeof entry.time === 'string' && Number.isFinite(Date.parse(entry.time))) && typeof state.updatedAt === 'string' && Number.isFinite(Date.parse(state.updatedAt));
  }
  // All game mutations enter here. Future turn rules can be added without DOM dependencies.
  function transition(state, action, now = new Date().toISOString()) {
    if (!valid(state)) throw new Error('유효하지 않은 게임 상태입니다.');
    if (action.type === 'SELECT_LOCATION') {
      if (!locationIds.includes(action.location)) throw new Error('알 수 없는 지역입니다.');
      if (state.selectedLocation === action.location) return state;
      return { ...state, selectedLocation: action.location, updatedAt: now };
    }
    if (action.type === 'PLAN_EXPEDITION') {
      if (state.plannedLocation === state.selectedLocation) return state;
      const location = game.data.locations.find(item => item.id === state.selectedLocation);
      return { ...state, plannedLocation: location.id, updatedAt: now, log: [...state.log, { text: location.name + ' 탐사 계획을 기록했다. 출발 전 주변 지형과 예상 물자를 확인한다.', time: now }].slice(-50) };
    }
    throw new Error('지원하지 않는 행동입니다.');
  }
  game.state = Object.freeze({ create, valid, transition });
})(globalThis);
