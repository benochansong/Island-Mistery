(function (root) {
  'use strict';
  const game = root.IslandMystery;
  const $ = id => document.getElementById(id);
  const escape = value => String(value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const dateLabel = date => new Date(date).toLocaleString('ko-KR', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  function render(state) {
    const location = game.data.locations.find(item => item.id === state.selectedLocation);
    $('resources').innerHTML = game.data.resources.map(item => `<div class="resource"><span class="resource-icon" aria-hidden="true">${item.icon}</span><span>${item.name}<small>공동 물자</small></span><strong>${state.resources[item.id]}<small>${item.unit}</small></strong></div>`).join('');
    if (!$('map-locations').children.length) {
      $('map-locations').innerHTML = game.data.locations.map(item => `<button class="map-pin" data-location="${item.id}" style="--x:${item.x}%;--y:${item.y}%" aria-pressed="false"><span class="pin-symbol" aria-hidden="true">${item.marker}</span><span class="pin-name">${item.name}</span></button>`).join('');
    }
    document.querySelectorAll('[data-location]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.location === state.selectedLocation)));
    $('location-details').innerHTML = `<div class="location-icon" aria-hidden="true">${location.marker}</div><p class="location-kicker">${location.label}</p><h2 id="location-title">${location.name}</h2><p class="location-description">${location.description}</p><dl class="location-facts"><div><dt>예상 자원</dt><dd>${location.resources}</dd></div><div><dt>예상 위험도</dt><dd class="risk-${location.risk === '높음' ? 'high' : 'normal'}">${location.risk}</dd></div></dl>`;
    const planned = state.plannedLocation === state.selectedLocation;
    $('plan-button').textContent = planned ? '이 지역으로 계획됨' : '탐사 계획에 기록';
    $('plan-button').disabled = planned;
    $('survivors').innerHTML = state.players.map((person, index) => `<article class="survivor"><div class="avatar avatar-${index}" aria-hidden="true">${escape(person.initials)}</div><div><h3>${escape(person.name)}${index === 0 ? '<span class="you">나</span>' : ''}</h3><p>${escape(person.personality)}</p><span class="health">건강</span></div></article>`).join('');
    $('journal').innerHTML = state.log.slice().reverse().map(entry => `<li><span class="log-time">1일차 · 아침</span><p>${escape(entry.text)}</p></li>`).join('');
    $('log-count').textContent = state.log.length + '개 기록';
  }
  function screen(name) {
    $('welcome').hidden = name !== 'welcome';
    $('game').hidden = name !== 'game';
    const heading = document.querySelector(name === 'game' ? '.game-heading h1' : '#welcome-title');
    heading.tabIndex = -1;
    heading.focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }
  function saveStatus(saved) { $('save-status').textContent = saved ? '자동 저장됨 · 이 브라우저에 보관' : '저장 불가 · 현재 화면에서는 계속 사용할 수 있습니다. 브라우저 저장 권한을 확인해 주세요.'; }
  function welcome(result, hasSession) {
    $('continue-button').disabled = !result.state && !hasSession;
    $('save-description').textContent = hasSession ? '현재 기록을 이어서 확인할 수 있습니다.' : ({ empty: '아직 저장된 기록이 없습니다.', invalid: '이전 저장 데이터를 읽을 수 없습니다. 새 기록을 시작할 수 있습니다.', unavailable: '브라우저 저장소에 접근할 수 없습니다. 이번 실행 중에는 이용할 수 있습니다.', loaded: result.state ? dateLabel(result.state.updatedAt) + ' · 1일차 탐사 준비' : '' })[result.status];
  }
  game.ui = Object.freeze({ $, render, screen, saveStatus, welcome });
})(globalThis);
