const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
function setup(storage) {
  const context = vm.createContext({ localStorage: storage || { getItem() { return this.value || null; }, setItem(key, value) { this.value = value; } } });
  for (const file of ['data', 'state', 'storage']) vm.runInContext(fs.readFileSync(path.join(__dirname, '../js/' + file + '.js'), 'utf8'), context);
  return context.IslandMystery;
}
const timestamp = '2026-11-20T00:00:00.000Z';
test('new session has six unique survivors and declared initial resources', () => {
  const game = setup(); const state = game.state.create(timestamp);
  assert.equal(game.state.valid(state), true);
  assert.equal(new Set(state.players.map(person => person.id)).size, 6);
  assert.equal(state.players.every(person => person.role === null), true);
  assert.equal(JSON.stringify(state.resources), JSON.stringify({ food: 12, water: 12, medicine: 3, parts: 2 }));
});
test('selection is immutable, planning records a choice without simulating exploration', () => {
  const game = setup(); const initial = game.state.create(timestamp);
  const selected = game.state.transition(initial, { type: 'SELECT_LOCATION', location: 'lab' }, timestamp);
  const planned = game.state.transition(selected, { type: 'PLAN_EXPEDITION' }, timestamp);
  assert.equal(initial.selectedLocation, 'coast'); assert.equal(initial.log.length, 1);
  assert.equal(planned.plannedLocation, 'lab'); assert.equal(planned.log.length, 2);
  assert.equal(planned.resources, initial.resources); assert.equal(planned.day, 1);
  assert.equal(game.state.transition(planned, { type: 'PLAN_EXPEDITION' }), planned);
});
test('invalid actions fail, history is bounded, and each new session is isolated', () => {
  const game = setup(); let state = game.state.create(timestamp);
  assert.throws(() => game.state.transition(state, { type: 'SELECT_LOCATION', location: 'missing' }));
  assert.throws(() => game.state.transition(state, { type: 'NEXT_DAY' }));
  for (let i = 0; i < 100; i++) {
    state = game.state.transition(state, { type: 'SELECT_LOCATION', location: i % 2 ? 'tower' : 'lab' }, timestamp);
    state = game.state.transition(state, { type: 'PLAN_EXPEDITION' }, timestamp);
  }
  assert.equal(state.log.length, 50); assert.equal(game.state.valid(state), true);
  const fresh = game.state.create(timestamp); fresh.players[0].name = 'changed';
  assert.equal(game.state.create(timestamp).players[0].name, '당신');
});
test('saved state restores in a separate runtime', () => {
  const backing = { getItem() { return this.value || null; }, setItem(key, value) { this.value = value; } };
  const game = setup(backing); assert.equal(game.storage.load().status, 'empty');
  let state = game.state.create(timestamp);
  state = game.state.transition(state, { type: 'SELECT_LOCATION', location: 'jungle' }, timestamp);
  state = game.state.transition(state, { type: 'PLAN_EXPEDITION' }, timestamp);
  assert.equal(game.storage.save(state), true);
  const restored = setup(backing).storage.load();
  assert.equal(restored.status, 'loaded'); assert.equal(JSON.stringify(restored.state), JSON.stringify(state));
});
test('corrupt, incompatible and malformed saves are rejected without deleting data', () => {
  for (const raw of ['{', '{}', 'null', 'x'.repeat(100001)]) {
    const backing = { getItem() { return raw; }, setItem() { throw new Error('must not write'); } };
    assert.equal(setup(backing).storage.load().status, 'invalid');
  }
  const game = setup();
  for (const mutate of [s => s.version = 2, s => s.players.pop(), s => s.resources.food = -1, s => s.selectedLocation = 'no', s => s.updatedAt = 'no', s => s.log[0].text = {}, s => s.players[0].name = '<script>']) {
    const state = game.state.create(timestamp); mutate(state);
    assert.equal(game.state.valid(state), false); assert.equal(game.storage.save(state), false);
  }
});
test('storage restrictions never crash gameplay', () => {
  const game = setup({ getItem() { throw new Error('blocked'); }, setItem() { throw new Error('quota'); } });
  assert.equal(game.storage.load().status, 'unavailable');
  const state = game.state.create(timestamp); assert.equal(game.storage.save(state), false);
  assert.equal(game.state.transition(state, { type: 'PLAN_EXPEDITION' }).plannedLocation, 'coast');
});
